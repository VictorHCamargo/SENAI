num = int(input("Digite um numero aleátorio:"))
num2 = int(input("Digite outro numero aleátorio:"))
if (num == num2):
    print("Os dois numeros são iguais!!")
else:
    print("São numeros diferentes!!")

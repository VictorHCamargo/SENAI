num = int(input("Digite um número:"))
parouimpar = num % 2
if (parouimpar == 0):
    print("Seu número", num, "é par")
else:
    print("Seu número", num, "é impar")

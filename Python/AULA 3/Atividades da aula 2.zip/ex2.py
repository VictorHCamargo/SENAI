caractere1 = str(input("Digite qualquer caractere:"))
caractere2 = str(input("Digite outro caractere:"))
print(f"O usuário digitou {caractere1} e {caractere2}")
num = int(input("Digite qualquer número inteiro:"))
print(f"O antecessor e o sucessor do número:{num} é, respectivamente, {num-1} e {num+1}")
num = int(input("Digite um número inteiro aleatório:"))
quadrado = num**2
print(f"O quadrado do número {num} é {quadrado}")
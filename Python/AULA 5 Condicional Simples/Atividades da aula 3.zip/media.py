# Declarações das variavéis
media = float(input("Digite sua media:"))
# Declarações das condições (utilizando if)
if media > 5:
    #Impressão dos resultados
    print("Aprovado")
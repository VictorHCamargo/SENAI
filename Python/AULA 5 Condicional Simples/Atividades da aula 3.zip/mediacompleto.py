media = float(input("Digite sua media:"))
if media > 7:
    print("Aprovado")
elif media < 5:
    print("Reprovado")
else:
    print("Recuperação")